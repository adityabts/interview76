import 'package:flutter/foundation.dart';
import 'package:interview76/Model/Movies.dart';
import 'package:interview76/Repository/MovieRepository.dart';
import 'package:interview76/Repository/apis/api_responces.dart';

class MovieslistViewModel extends ChangeNotifier{

  ApiResponse _apiResponse = ApiResponse.initial('Empty data');

  Movies? movielist;

  ApiResponse get response {
    return _apiResponse;
  }

  Movies? get MoviesList {
    return movielist;
  }

  Future<void> fetchMovieData() async {
    _apiResponse = ApiResponse.loading('Fetching artist data');
    notifyListeners();
    try {
      List<Movies> MoviesList = await MovieRepository().fetchMoviesList();
      _apiResponse = ApiResponse.completed(MoviesList);
    } catch (e) {
      _apiResponse = ApiResponse.error(e.toString());
      print(e);
    }
    notifyListeners();
  }

  void setSelectedMedia(Movies? movielist) {
    movielist = movielist;
    notifyListeners();
  }

}