abstract class BaseService {
  final String BaseUrl = "https://www.omdbapi.com/?apikey=39a36280&s=iron%20man";

  Future<dynamic> getResponse();

}