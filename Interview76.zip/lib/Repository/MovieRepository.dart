

import 'package:interview76/Model/Movies.dart';

import 'BaseServices.dart';
import 'MoviesServices.dart';

class MovieRepository{
  BaseService _mediaService = MediaService();

  Future<List<Movies>> fetchMoviesList() async {
    dynamic response = await _mediaService.getResponse();
    print(response);
    final jsonData = response['results'] as List;
    List<Movies> MoviesList = jsonData.map((tagJson) => Movies.fromJson(tagJson)).toList();
    return MoviesList;
   }
}