import 'package:flutter/material.dart';


const TextStyle apptext = TextStyle(
  fontSize: 20.0,color: Colors.black,fontWeight: FontWeight.w600
);