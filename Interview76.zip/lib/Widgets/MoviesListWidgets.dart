import 'package:flutter/material.dart';

import '../Views/MoviesDetails.dart';

class MovieListWidgets extends StatefulWidget {
  const MovieListWidgets({Key? key}) : super(key: key);

  @override
  State<MovieListWidgets> createState() => _MovieListWidgetsState();
}

class _MovieListWidgetsState extends State<MovieListWidgets> {
  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    final width = MediaQuery.of(context).size.width;
    return Container(
      height: height*0.5,
      child: ListView.builder(
          scrollDirection: Axis.horizontal,
          shrinkWrap: true,
          physics: ScrollPhysics(),
          itemCount: 10,
          itemBuilder: (context,index){
            return InkWell(
              onTap: (){
                 Navigator.push(context,
                 MaterialPageRoute(builder: (context)=>MoviesDetails())
                 );
              },
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  border: Border.all(width: width*0.01)
                ),
                child: Column(
                  children: [
                    Text("Movies List")
                  ],
                ),
              ),
            );
          },
      ),
    );
  }
}
