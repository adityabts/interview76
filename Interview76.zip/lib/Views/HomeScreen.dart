import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:interview76/Model/Movies.dart';
import 'package:interview76/Repository/apis/api_responces.dart';
import 'package:interview76/Utils/app_text.dart';
import 'package:interview76/ViewModel/MovieListViewModel.dart';
import 'package:provider/provider.dart';

import '../Widgets/MoviesListWidgets.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  MovieslistViewModel moveieslist = MovieslistViewModel();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }



  @override
  Widget build(BuildContext context) {
    ApiResponse apiResponse = Provider.of<MovieslistViewModel>(context).response;
    return Scaffold(
       appBar: AppBar(
         backgroundColor: Colors.black12,
         centerTitle: true,
         title: Text("Movies Screen",style: GoogleFonts.roboto(
           textStyle: apptext
         )),
       ),
      body: Column(
        children: [
           ElevatedButton(
               onPressed: (){
                moveieslist.fetchMovieData();
               },
               child: Text("Get Movies list")),
          MovieListWidgets(),
        ],
      ),
    );
  }
}
