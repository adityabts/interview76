import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:interview76/Utils/app_text.dart';

class MoviesDetails extends StatefulWidget {
  const MoviesDetails({Key? key}) : super(key: key);

  @override
  State<MoviesDetails> createState() => _MoviesDetailsState();
}

class _MoviesDetailsState extends State<MoviesDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black12,
        centerTitle: true,
        title: Text("Movies Details Screen",style: GoogleFonts.roboto(
          textStyle: apptext
        ),),
      ),
    );
  }
}
